
n = 4000;
[M,W] = load_potential_map('road1', n);
%start_point = [16;219];
%end_point = [394;192];
% You can use instead the function
[start_point,end_point] = pick_start_end_point(W);

clear options;
options.nb_iter_max = Inf;
options.end_points = end_point; % stop propagation when end point reached
[D,S] = perform_fast_marching(W, start_point, options);
% nicde color for display
A = convert_distance_color(D);
imageplot({W A}, {'Potential map' 'Distance to starting point'}); 
colormap gray(256);