function m = mmin(A)

% mmin - maximum entry from a matrix.
%
%   m = mmin(A);
%
%   Copyright (c) 2004 Gabriel Peyr�

m = min(A(:));