%% Robot formations path planning with Fast Marching Square

%% This code is licensed under Creative Commons Attribution Share-Alike 3.0
% for the details about this license please go to
% http://creativecommons.org/licenses/by-sa/3.0/

%% Author: Javier V. Gómez  -  www.javiervgomez.com jvgomez _at_ ing.uc3m.es
% Date:  06/02/2013

%% If you use this code, please, cite the following paper:

% "Fast Marching Methods in Path Planning"
% Authors: J.V. Gómez, A. Lumbier, S. Garrido and L. Moreno
%Journal:  Accepted for publication in the IEEE Robotics and Automation Magazine

clear all;
close all;

%% Parameters
sat = 0.5;

Wo = flip_vertical(imread('map.bmp'));

SE = strel('disk',10);  % Dilation of obstacles.
Woo = ~imdilate(Wo, SE);

%Black borders.
Wo(1,:) = 0;
Wo(end,:) = 0;
Wo(:,1) = 0;
Wo(:,end) = 0;

W = FMdist(Wo');
W = rescale(W);

% Velocities saturation.
W = min (W,sat);
W = rescale(W);

[start_point,end_point] = pick_start_end_point(Wo');
options.nb_iter_max = Inf;
options.Tmax        = sum(size(W));

%Path with FM² with no saturation.
tic();
[D,S] = perform_fast_marching_2d(W, start_point, options);

path = extract_path_2d(D,end_point, options);
 
vel= [];
for i=1:length(path)
    vel = [vel; W(round(path(i,1)),round(path(i,2))) i]; 
end

figure;
plot_fast_marching_2d(Wo',[],path,start_point,end_point);
colormap gray(256);

figure;
plot(vel(:,2),vel(:,1));
