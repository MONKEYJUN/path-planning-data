%% This code is licensed under Creative Commons Attribution Share-Alike 3.0
% for the details about this license please go to
% http://creativecommons.org/licenses/by-sa/3.0/

%% Author: Javier V. Gómez  -  www.javiervgomez.com jvgomez _at_ ing.uc3m.es
% Date:  06/02/2013

function D = FMdist(W)
W = rescale( double(W) );
[row,col]=find(W<0.5);
start_points=[row,col]';
options.nb_iter_max = Inf;
options.Tmax = sum(size(W));
%disp('Performing front propagation.');
[D,~] = perform_fast_marching_2d(W, start_points, options);
%D = rescale( double(D) );
