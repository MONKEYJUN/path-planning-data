%% This code is licensed under Creative Commons Attribution Share-Alike 3.0
% for the details about this license please go to
% http://creativecommons.org/licenses/by-sa/3.0/

%% Author: Javier V. Gómez  -  www.javiervgomez.com jvgomez _at_ ing.uc3m.es
% Date:  06/02/2013

function z=euc_dist(x,y)

z=sqrt((y-x)'*(y-x));
 
